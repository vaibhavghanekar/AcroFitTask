
package com.example.shree.acrofittask.models;

import com.google.gson.annotations.Expose;
import com.google.gson.annotations.SerializedName;

public class Feed {

    @SerializedName("feed")
    @Expose
    private Feed_ feed;

    public Feed_ getFeed() {
        return feed;
    }

    public void setFeed(Feed_ feed) {
        this.feed = feed;
    }

}
