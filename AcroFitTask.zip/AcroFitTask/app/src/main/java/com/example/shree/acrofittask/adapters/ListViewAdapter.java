package com.example.shree.acrofittask.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import com.example.shree.acrofittask.R;
import com.example.shree.acrofittask.activities.MainActivity;
import com.example.shree.acrofittask.models.Result;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;

/**
 * Created by vaibhav on 01-Aug-17.
 */
public class ListViewAdapter extends BaseAdapter {

    Context mainActivity;
    ArrayList<Result> resultArrayList;
    LayoutInflater layoutInflaterl;

    public ListViewAdapter(MainActivity mainActivity, ArrayList<Result> resultArrayList) {
        this.mainActivity = mainActivity;
        this.resultArrayList = resultArrayList;
    }

    class ViewHolder {
        TextView artistName;
        TextView releaseDate;
        TextView copyright;
        TextView albumName;
        ImageView pic;
    }

    @Override
    public int getCount() {
        return resultArrayList.size();
    }

    @Override
    public Object getItem(int position) {
        return resultArrayList.get(position);
    }

    @Override
    public long getItemId(int position) {
        return resultArrayList.indexOf(position);
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        ViewHolder viewHolder;
        if (convertView == null) {
            layoutInflaterl = (LayoutInflater) mainActivity.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            convertView = layoutInflaterl.inflate(R.layout.single_row, parent, false);

            viewHolder = new ViewHolder();
            viewHolder.albumName = convertView.findViewById(R.id.tv_albumname);
            viewHolder.artistName = convertView.findViewById(R.id.tv_artistname);
            viewHolder.releaseDate = convertView.findViewById(R.id.tv_releaseDate);
            viewHolder.copyright = convertView.findViewById(R.id.tv_copyright);
            viewHolder.pic = convertView.findViewById(R.id.img_pic);

            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
        }

        viewHolder.artistName.setText(resultArrayList.get(position).getArtistName());
        viewHolder.releaseDate.setText(resultArrayList.get(position).getReleaseDate());
        viewHolder.copyright.setText(resultArrayList.get(position).getCopyright());
        viewHolder.albumName.setText(resultArrayList.get(position).getName());
        Picasso.with(mainActivity)
                .load(resultArrayList.get(position).getArtworkUrl100())
                .into(viewHolder.pic);

        return convertView;
    }
}
