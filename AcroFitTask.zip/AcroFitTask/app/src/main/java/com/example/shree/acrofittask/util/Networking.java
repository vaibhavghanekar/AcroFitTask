package com.example.shree.acrofittask.util;

import android.app.Activity;
import android.app.ProgressDialog;
import android.util.Log;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;
import com.example.shree.acrofittask.R;
import org.json.JSONObject;

/**
 * Created by vaibhav on 22-Aug-17.
 */

public class Networking {
    NetworkingCallBack callBack;
    ProgressDialog progressDialog;

    //Singleton.
    private Networking() {
    }

    public static Networking getInstance() {
        return new Networking();
    }

    //Volley API Code for web service communication.
    public void getRequest(final Activity activity, String url) {
        showProgressDialog(activity, activity.getString(R.string.progressdialog));

        callBack = (NetworkingCallBack) activity;
        RequestQueue queue = Volley.newRequestQueue(activity);

        JsonObjectRequest jsObjRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                progressDialog.dismiss();
                Log.d("response=>", response.toString());
                callBack.networkingCallBackResult(0, response.toString());
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                progressDialog.dismiss();
                Log.d("response=>", String.valueOf(error));
                callBack.networkingCallBackResult(1, error.toString());
            }
        });
        queue.add(jsObjRequest);
    }

    //CallBack navigates to the activity after web service communication is done.
    public interface NetworkingCallBack {
        public void networkingCallBackResult(int i, String s);
    }

    //Handles ProgressDialogs.
    public void showProgressDialog(Activity activity, String str) {
        progressDialog = new ProgressDialog(activity);
        progressDialog.setMessage(str);
        progressDialog.setCancelable(false);
        progressDialog.show();
    }
}
