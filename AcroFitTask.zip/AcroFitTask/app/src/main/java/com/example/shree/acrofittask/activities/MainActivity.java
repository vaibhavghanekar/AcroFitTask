package com.example.shree.acrofittask.activities;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.widget.ListView;
import android.widget.Toast;
import com.example.shree.acrofittask.R;
import com.example.shree.acrofittask.adapters.ListViewAdapter;
import com.example.shree.acrofittask.models.Feed;
import com.example.shree.acrofittask.models.Result;
import com.example.shree.acrofittask.util.Networking;
import com.google.gson.Gson;
import java.util.ArrayList;
import butterknife.ButterKnife;
import butterknife.InjectView;

public class MainActivity extends AppCompatActivity implements Networking.NetworkingCallBack {
    //NetworkingCallBack Interface for callback after webserice communication is done.

    String url = "";
    @InjectView(R.id.lv_1)
    ListView listView;
    ArrayList<Result> resultArrayList;
    ListViewAdapter arrayAdapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ButterKnife.inject(this);

        resultArrayList = new ArrayList<>();
        url = "https://rss.itunes.apple.com/api/v1/us/apple-music/new-music/10/explicit.json";

        callWebService();
    }

    //Calls  the webservice.
    private void callWebService() {
        Networking.getInstance().getRequest(MainActivity.this, url);
    }

    //Processes the data from webservice.
    @Override
    public void networkingCallBackResult(int i, String response) {
        if (i == 0) {
            Toast.makeText(this, "success", Toast.LENGTH_SHORT).show();

            String json = String.valueOf(response);
            Gson gson = new Gson();
            Feed feed = gson.fromJson(json, Feed.class);

            for (Result result : feed.getFeed().getResults()) {
                resultArrayList.add(result);
            }
            arrayAdapter = new ListViewAdapter(MainActivity.this, resultArrayList);
            listView.setAdapter(arrayAdapter);
        } else {
            Toast.makeText(this, "Error fetching result...trying again!", Toast.LENGTH_SHORT).show();
            callWebService();
        }

    }
}
